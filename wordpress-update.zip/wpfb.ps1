﻿$drec2=Get-SSMParameter -Name drwebinstanceid -Region us-east-2
Stop-EC2Instance -Region us-east-2 -InstanceId $drec2.Value -Enforce 1
$aminame = "DRWebserver-$(get-date -Format %d-%M-%y-%H-%m)"
$AMIinprogress=New-EC2Image -InstanceId $drec2.Value -Region us-east-2 -NoReboot 1 -Description $tagDesc -Name $aminame
do
{
Start-Sleep -Seconds 60
$imglatest=Get-EC2Image -ImageId $AMIinprogress -Region us-east-2
$imglatest.State
} until ($imglatest.State -eq "available")
Write-SSMParameter -Name failbackwebamiid -Value $imglatest.ImageId -Region us-east-2 -Type String -Overwrite 1
$copy=Copy-EC2Image -SourceImageId $imglatest.ImageId -SourceRegion us-east-2 -Region us-west-2 -Name $aminame
do
{
Write-Host "Copy in progress. will check after 60 seconds"
Start-Sleep -Seconds 60
$copystat=Get-EC2Image -ImageId $copy -Region us-west-2
$copystat.State
} until ($copystat.State -eq "available")
$drimglatest = $copystat
$drimglatest
Write-SSMParameter -Name failbackwebamiid -Value $drimglatest.ImageId -Region us-west-2 -Type String -Overwrite 1